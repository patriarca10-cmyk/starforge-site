/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { StarBackground } from './components/StarBackground';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { GameUrlWarningModal } from './components/GameUrlWarningModal';
import { ProtectedRoute, PublicOnlyRoute } from './components/RouteGuards';

import { LandingPage } from './pages/LandingPage';
import { RegisterPage } from './pages/RegisterPage';
import { LoginPage } from './pages/LoginPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { DashboardPage } from './pages/DashboardPage';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <div className="space-background min-h-screen flex flex-col relative text-slate-100 selection:bg-[#edc765]/30 selection:text-[#fcedb3]">
          {/* Fundo Estelar Animado */}
          <StarBackground />

          {/* Barra de Navegação Superior (Contrato de 3 Zonas) */}
          <Navbar />

          {/* Conteúdo Principal com Rotas */}
          <main className="flex-1 flex flex-col">
            <Routes>
              {/* Página Inicial */}
              <Route path="/" element={<LandingPage />} />

              {/* Criação de Conta (Página Principal) */}
              <Route
                path="/cadastro"
                element={
                  <PublicOnlyRoute>
                    <RegisterPage />
                  </PublicOnlyRoute>
                }
              />

              {/* Login */}
              <Route
                path="/entrar"
                element={
                  <PublicOnlyRoute>
                    <LoginPage />
                  </PublicOnlyRoute>
                }
              />

              {/* Recuperação de Senha */}
              <Route
                path="/esqueci-senha"
                element={
                  <PublicOnlyRoute>
                    <ForgotPasswordPage />
                  </PublicOnlyRoute>
                }
              />

              {/* Redefinição de Senha via Link de E-mail */}
              <Route path="/redefinir-senha" element={<ResetPasswordPage />} />

              {/* Painel do Piloto (Protegido) */}
              <Route
                path="/painel"
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                }
              />

              {/* Rota Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>

          {/* Rodapé Estelar */}
          <Footer />

          {/* Modal de Aviso se GAME_URL ainda não estiver preenchida */}
          <GameUrlWarningModal />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
}
