import React from 'react';
import { Shield, Sparkles, Terminal } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-[#315d78]/30 bg-[#02050c]/90 text-slate-400 py-10 px-4 sm:px-6 lg:px-8 mt-auto z-10 relative">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs">
        
        {/* Info do jogo */}
        <div className="flex flex-col items-center md:items-start gap-1">
          <div className="flex items-center gap-2">
            <span className="font-orbitron font-bold text-slate-200 tracking-wider">
              STARFORGE: VOID RUN
            </span>
            <span className="text-[#edc765]">•</span>
            <span className="text-slate-400">Terminal de Autenticação</span>
          </div>
          <p className="text-slate-500 text-[11px] text-center md:text-left">
            Space shooter roguelite estelar com dungeons no vazio, guildas e raids cooperativas.
          </p>
        </div>

        {/* Protocolos de segurança */}
        <div className="flex items-center gap-6 text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#80edbd]" />
            Criptografia Supabase Auth
          </span>
          <span className="flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-[#64baff]" />
            Fragment Token Protocol (#)
          </span>
        </div>

        {/* Copyright */}
        <div className="text-slate-500 text-[11px]">
          &copy; {new Date().getFullYear()} Starforge Void Run. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};
