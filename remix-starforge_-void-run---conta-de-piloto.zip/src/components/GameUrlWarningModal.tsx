import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { AlertTriangle, X, ExternalLink } from 'lucide-react';
import { clearLocalAuthTokens } from '../lib/supabase';

export const GameUrlWarningModal: React.FC = () => {
  const { session, showGameUrlWarning, setShowGameUrlWarning } = useAuth();
  const [customUrl, setCustomUrl] = useState('');

  if (!showGameUrlWarning) return null;

  const handleLaunchWithCustomUrl = () => {
    if (!customUrl) return;
    let url = customUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = `https://${url}`;
    }

    if (session) {
      const targetUrl = `${url}#access_token=${encodeURIComponent(
        session.access_token
      )}&refresh_token=${encodeURIComponent(session.refresh_token)}`;

      clearLocalAuthTokens();
      window.location.href = targetUrl;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div 
        className="starforge-panel max-w-lg w-full p-6 sm:p-7 relative border-[#edc765] shadow-[0_0_30px_rgba(237,199,101,0.25)]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <button
          onClick={() => setShowGameUrlWarning(false)}
          className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
          aria-label="Fechar aviso"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[#edc765] shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 id="modal-title" className="font-orbitron font-bold text-lg text-slate-100">
              URL do Jogo Não Configurada
            </h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Para direcionar os pilotos diretamente para a nave no Vercel, defina a constante{' '}
              <code className="bg-[#06101d] px-1.5 py-0.5 rounded border border-[#315d78] text-[#edc765] font-mono text-[11px]">
                GAME_URL
              </code>{' '}
              no arquivo <code className="text-[#64baff]">src/lib/config.ts</code>.
            </p>
          </div>
        </div>

        {/* Testar com URL imediata */}
        <div className="mt-5 space-y-3 bg-[#06101d]/80 border border-[#315d78]/60 p-4 rounded-lg">
          <label className="block text-xs font-semibold text-slate-200">
            Testar lançamento com URL personalizada agora:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              placeholder="Ex: http://localhost:5173 ou https://supreme-forc.vercel.app"
              className="starforge-input flex-1 px-3 py-2 text-xs"
            />
            <button
              onClick={handleLaunchWithCustomUrl}
              disabled={!customUrl}
              className="btn-gold px-4 py-2 text-xs flex items-center gap-1.5 rounded"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Abrir</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Os tokens de autenticação <code className="text-[#64baff]">access_token</code> e{' '}
            <code className="text-[#64baff]">refresh_token</code> serão passados com segurança no fragmento (#).
          </p>
        </div>

        {/* Botão de Fechar */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={() => setShowGameUrlWarning(false)}
            className="btn-secondary px-5 py-2 text-xs rounded-lg cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
