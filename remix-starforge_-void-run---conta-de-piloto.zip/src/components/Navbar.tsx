import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Rocket, User, LogOut, Menu, X, ShieldAlert } from 'lucide-react';
import insigniaImg from '../assets/images/starforge_insignia_1790708457405.jpg';

export const Navbar: React.FC = () => {
  const { session, profile, signOut, launchGame } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const displayName = profile?.display_name || profile?.username || session?.user?.user_metadata?.username || 'Piloto';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#315d78]/40 bg-[#030711]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* Zone 1: Brand Wordmark */}
        <Link 
          to="/" 
          className="flex items-center gap-3 text-slate-100 group transition-transform duration-150 hover:scale-[1.01]"
        >
          <img 
            src={insigniaImg} 
            alt="Starforge Insígnia" 
            className="w-8 h-8 rounded border border-[#edc765]/60 object-cover shadow-[0_0_10px_rgba(237,199,101,0.3)]"
          />
          <div className="flex flex-col">
            <span className="font-orbitron font-extrabold text-base tracking-wider text-slate-100 group-hover:text-[#edc765] transition-colors">
              STARFORGE
            </span>
            <span className="text-[10px] font-orbitron tracking-widest text-[#64baff] uppercase -mt-1">
              VOID RUN
            </span>
          </div>
        </Link>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          <Link 
            to="/" 
            className={`transition-colors hover:text-[#edc765] ${location.pathname === '/' ? 'text-[#edc765]' : ''}`}
          >
            Início
          </Link>
          <a 
            href="/#sobre" 
            className="transition-colors hover:text-[#edc765]"
          >
            O Jogo
          </a>
          <a 
            href="/#recursos" 
            className="transition-colors hover:text-[#edc765]"
          >
            Naves & Raids
          </a>
          {session && (
            <Link 
              to="/painel" 
              className={`transition-colors hover:text-[#edc765] ${location.pathname === '/painel' ? 'text-[#edc765] font-semibold' : ''}`}
            >
              Hangar do Piloto
            </Link>
          )}
        </nav>

        {/* Zone 3: Actions */}
        <div className="hidden md:flex items-center gap-3">
          {session ? (
            <>
              <button
                onClick={launchGame}
                className="btn-gold px-4 py-2 text-xs uppercase tracking-wider flex items-center gap-2 rounded-lg cursor-pointer"
              >
                <Rocket className="w-3.5 h-3.5" />
                <span>Jogar Agora</span>
              </button>

              <Link
                to="/painel"
                className="btn-secondary px-3 py-2 text-xs flex items-center gap-2 rounded-lg"
                title={`Logado como ${displayName}`}
              >
                <User className="w-3.5 h-3.5 text-[#edc765]" />
                <span className="max-w-[110px] truncate">{displayName}</span>
              </Link>

              <button
                onClick={handleSignOut}
                aria-label="Encerrar sessão"
                className="p-2 text-slate-400 hover:text-[#ff9e9e] hover:bg-[#ff9e9e]/10 rounded-lg transition-colors"
                title="Sair da conta"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <Link
                to="/entrar"
                className="btn-secondary px-4 py-2 text-xs uppercase tracking-wider rounded-lg transition-colors"
              >
                Entrar
              </Link>

              <Link
                to="/cadastro"
                className="btn-gold px-4 py-2 text-xs uppercase tracking-wider rounded-lg"
              >
                Criar Conta
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-slate-300 hover:text-white rounded-lg focus:outline-none focus:ring-1 focus:ring-[#74e2ff]"
          aria-label="Abrir menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#315d78]/40 bg-[#060b16] px-4 pt-3 pb-6 space-y-4">
          <nav className="flex flex-col gap-3 text-sm">
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-slate-200 hover:text-[#edc765]"
            >
              Início
            </Link>
            <a
              href="/#sobre"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-slate-200 hover:text-[#edc765]"
            >
              O Jogo
            </a>
            <a
              href="/#recursos"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 text-slate-200 hover:text-[#edc765]"
            >
              Naves & Raids
            </a>
            {session && (
              <Link
                to="/painel"
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 text-[#edc765] font-semibold"
              >
                Hangar do Piloto ({displayName})
              </Link>
            )}
          </nav>

          <div className="pt-2 border-t border-[#315d78]/30 flex flex-col gap-2.5">
            {session ? (
              <>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    launchGame();
                  }}
                  className="btn-gold w-full py-2.5 text-center text-xs uppercase tracking-wider flex items-center justify-center gap-2 rounded-lg"
                >
                  <Rocket className="w-4 h-4" />
                  <span>JOGAR AGORA</span>
                </button>
                <button
                  onClick={handleSignOut}
                  className="w-full py-2 text-center text-xs text-[#ff9e9e] hover:bg-[#ff9e9e]/10 rounded-lg flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Desconectar Piloto</span>
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/cadastro"
                  onClick={() => setMobileMenuOpen(false)}
                  className="btn-gold w-full py-2.5 text-center text-xs uppercase tracking-wider rounded-lg block font-bold"
                >
                  Criar Conta de Piloto
                </Link>
                <Link
                  to="/entrar"
                  onClick={() => setMobileMenuOpen(false)}
                  className="btn-secondary w-full py-2.5 text-center text-xs uppercase tracking-wider rounded-lg block"
                >
                  Entrar no Terminal
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
