import React from 'react';
import { Check, X } from 'lucide-react';

interface PasswordStrengthMeterProps {
  password: string;
}

export const PasswordStrengthMeter: React.FC<PasswordStrengthMeterProps> = ({ password }) => {
  const hasMinLength = password.length >= 8;
  const hasMixedCase = /[a-z]/.test(password) && /[A-Z]/.test(password);
  const hasNumber = /\d/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);

  const passedCriteria = [hasMinLength, hasMixedCase, hasNumber, hasSpecial].filter(Boolean).length;

  const getStrengthLabel = () => {
    if (!password) return { label: 'Digite sua senha', color: 'text-slate-500', barBg: 'bg-slate-700', percent: 0 };
    if (passedCriteria <= 1) return { label: 'Fraca', color: 'text-[#ff9e9e]', barBg: 'bg-[#ff9e9e]', percent: 25 };
    if (passedCriteria === 2) return { label: 'Média', color: 'text-amber-400', barBg: 'bg-amber-400', percent: 50 };
    if (passedCriteria === 3) return { label: 'Forte', color: 'text-[#64baff]', barBg: 'bg-[#64baff]', percent: 75 };
    return { label: 'Excelente', color: 'text-[#80edbd]', barBg: 'bg-[#80edbd]', percent: 100 };
  };

  const strength = getStrengthLabel();

  if (!password) return null;

  return (
    <div className="mt-2 space-y-2 text-xs" aria-live="polite">
      {/* Barra de progresso */}
      <div className="flex items-center justify-between">
        <span className="text-slate-400">Força da blindagem:</span>
        <span className={`font-semibold ${strength.color}`}>{strength.label}</span>
      </div>

      <div className="w-full bg-[#06101d] border border-[#315d78]/40 h-1.5 rounded-full overflow-hidden">
        <div
          className={`h-full transition-all duration-300 ${strength.barBg}`}
          style={{ width: `${strength.percent}%` }}
        />
      </div>

      {/* Critérios com ícones acessíveis */}
      <div className="grid grid-cols-2 gap-1.5 pt-1 text-[11px] text-slate-400">
        <div className={`flex items-center gap-1 ${hasMinLength ? 'text-[#80edbd]' : 'text-slate-500'}`}>
          {hasMinLength ? <Check className="w-3 h-3 text-[#80edbd]" /> : <X className="w-3 h-3 text-slate-500" />}
          <span>Mínimo 8 caracteres</span>
        </div>
        <div className={`flex items-center gap-1 ${hasMixedCase ? 'text-[#80edbd]' : 'text-slate-500'}`}>
          {hasMixedCase ? <Check className="w-3 h-3 text-[#80edbd]" /> : <X className="w-3 h-3 text-slate-500" />}
          <span>Maiúsculas e minúsculas</span>
        </div>
        <div className={`flex items-center gap-1 ${hasNumber ? 'text-[#80edbd]' : 'text-slate-500'}`}>
          {hasNumber ? <Check className="w-3 h-3 text-[#80edbd]" /> : <X className="w-3 h-3 text-slate-500" />}
          <span>Pelo menos um número</span>
        </div>
        <div className={`flex items-center gap-1 ${hasSpecial ? 'text-[#80edbd]' : 'text-slate-500'}`}>
          {hasSpecial ? <Check className="w-3 h-3 text-[#80edbd]" /> : <X className="w-3 h-3 text-slate-500" />}
          <span>Símbolo especial (!@#$)</span>
        </div>
      </div>
    </div>
  );
};
