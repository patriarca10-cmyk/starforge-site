import React from 'react';
import { RefreshCw, Coins, Gem, Sparkles, Layers, AlertCircle } from 'lucide-react';
import { Profile } from '../lib/supabase';

interface PilotWalletProps {
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  onRefresh: () => Promise<void>;
}

export const PilotWallet: React.FC<PilotWalletProps> = ({
  profile,
  loading,
  error,
  onRefresh,
}) => {
  // Extrai com segurança os valores de game_data de public.profiles
  const gameData =
    profile?.game_data && typeof profile.game_data === 'object'
      ? (profile.game_data as Record<string, any>)
      : {};

  // coins = Number(game_data.coins ?? 120), gems = Number(game_data.gems ?? 8), shards = Number(game_data.shards ?? 4)
  const rawCoins = Number(gameData.coins ?? 120);
  const coins = !isNaN(rawCoins) && isFinite(rawCoins) ? rawCoins : 120;

  const rawGems = Number(gameData.gems ?? 8);
  const gems = !isNaN(rawGems) && isFinite(rawGems) ? rawGems : 8;

  const rawShards = Number(gameData.shards ?? 4);
  const shards = !isNaN(rawShards) && isFinite(rawShards) ? rawShards : 4;

  return (
    <section className="space-y-4" aria-label="Carteira de recursos do piloto">
      {/* Barra de título da carteira com botão Atualizar e texto informativo */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1 border-b border-[#315d78]/40">
        <div>
          <h2 className="font-orbitron font-bold text-base sm:text-lg text-slate-100 flex items-center gap-2">
            <span>Carteira do Piloto</span>
            <span className="text-[11px] font-orbitron font-normal px-2 py-0.5 rounded bg-[#315d78]/30 border border-[#315d78]/50 text-[#64baff]">
              SOMENTE LEITURA
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Valores da última sincronização do jogo
          </p>
        </div>

        <button
          onClick={onRefresh}
          disabled={loading}
          aria-label="Atualizar recursos da carteira"
          className="btn-secondary px-3.5 py-1.5 text-xs rounded-lg flex items-center gap-2 self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#edc765] ${loading ? 'animate-spin' : ''}`} />
          <span>↻ Atualizar</span>
        </button>
      </div>

      {/* Alerta amigável se a busca do perfil falhar, sem quebrar o painel */}
      {error && !profile && !loading && (
        <div 
          className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center gap-2.5 text-xs text-amber-200"
          role="alert"
        >
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            Não foi possível carregar os dados em tempo real da carteira. Mostrando valores locais padrão. Clique em "↻ Atualizar" para sincronizar novamente.
          </span>
        </div>
      )}

      {/* Grid com os 3 Cartões de Recursos */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* 1. CRÉDITOS */}
        <div className="starforge-panel p-5 relative overflow-hidden border-[#edc765]/80 hover:border-[#edc765] transition-colors group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-orbitron font-semibold tracking-wider text-slate-300 uppercase">
              Créditos
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#edc765]/15 border border-[#edc765]/50 flex items-center justify-center text-[#edc765] group-hover:scale-105 transition-transform">
              <Coins className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            {loading ? (
              <div className="h-8 w-28 bg-[#06101d] rounded animate-pulse border border-[#315d78]/40" />
            ) : (
              <div className="font-orbitron font-black text-2xl sm:text-3xl text-[#fcedb3] tabular-nums tracking-tight">
                {coins.toLocaleString('pt-BR')}
              </div>
            )}
            <p className="text-[11px] text-slate-400 mt-1">
              Moeda oficial da Federação
            </p>
          </div>

          {/* Brilho decorativo sutil */}
          <div className="absolute -bottom-6 -right-6 w-16 h-16 bg-[#edc765]/10 rounded-full blur-xl pointer-events-none" />
        </div>

        {/* 2. GEMAS */}
        <div className="starforge-panel p-5 relative overflow-hidden border-[#64baff]/80 hover:border-[#64baff] transition-colors group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-orbitron font-semibold tracking-wider text-slate-300 uppercase">
              Gemas
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#64baff]/15 border border-[#64baff]/50 flex items-center justify-center text-[#64baff] group-hover:scale-105 transition-transform">
              <Gem className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            {loading ? (
              <div className="h-8 w-24 bg-[#06101d] rounded animate-pulse border border-[#315d78]/40" />
            ) : (
              <div className="font-orbitron font-black text-2xl sm:text-3xl text-[#74e2ff] tabular-nums tracking-tight">
                {gems.toLocaleString('pt-BR')}
              </div>
            )}
            <p className="text-[11px] text-slate-400 mt-1">
              Cristais raros de hiper-propulsão
            </p>
          </div>

          {/* Brilho decorativo sutil */}
          <div className="absolute -bottom-6 -right-6 w-16 h-16 bg-[#64baff]/10 rounded-full blur-xl pointer-events-none" />
        </div>

        {/* 3. FRAGMENTOS */}
        <div className="starforge-panel p-5 relative overflow-hidden border-[#80edbd]/80 hover:border-[#80edbd] transition-colors group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-orbitron font-semibold tracking-wider text-slate-300 uppercase">
              Fragmentos
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#80edbd]/15 border border-[#80edbd]/50 flex items-center justify-center text-[#80edbd] group-hover:scale-105 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            {loading ? (
              <div className="h-8 w-20 bg-[#06101d] rounded animate-pulse border border-[#315d78]/40" />
            ) : (
              <div className="font-orbitron font-black text-2xl sm:text-3xl text-[#80edbd] tabular-nums tracking-tight">
                {shards.toLocaleString('pt-BR')}
              </div>
            )}
            <p className="text-[11px] text-slate-400 mt-1">
              Matéria prima das dungeons do vazio
            </p>
          </div>

          {/* Brilho decorativo sutil */}
          <div className="absolute -bottom-6 -right-6 w-16 h-16 bg-[#80edbd]/10 rounded-full blur-xl pointer-events-none" />
        </div>

      </div>
    </section>
  );
};
