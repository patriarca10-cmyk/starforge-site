import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-[#edc765] animate-spin" />
        <span className="font-orbitron text-xs tracking-widest text-slate-400 uppercase">
          Sincronizando com o Núcleo Estelar...
        </span>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/entrar" replace />;
  }

  return <>{children}</>;
};

export const PublicOnlyRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-[#edc765] animate-spin" />
        <span className="font-orbitron text-xs tracking-widest text-slate-400 uppercase">
          Carregando Terminal...
        </span>
      </div>
    );
  }

  if (session) {
    return <Navigate to="/painel" replace />;
  }

  return <>{children}</>;
};
