import React, { useMemo } from 'react';

export const StarBackground: React.FC = () => {
  // Gera posições e brilhos fixos de estrelas para evitar re-renderizações caras
  const stars = useMemo(() => {
    return Array.from({ length: 70 }, (_, i) => ({
      id: i,
      x: (i * 37) % 100,
      y: (i * 53) % 100,
      size: (i % 3 === 0 ? 2.5 : i % 2 === 0 ? 1.5 : 1),
      opacity: 0.2 + ((i % 5) * 0.15),
      animClass: i % 3 === 0 ? 'animate-twinkle-1' : i % 2 === 0 ? 'animate-twinkle-2' : 'animate-twinkle-3',
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {/* Nebulosas cósmicas sutis */}
      <div 
        className="absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-20 animate-nebula"
        style={{ background: 'radial-gradient(circle, #315d78 0%, rgba(6,11,22,0) 70%)' }}
      />
      <div 
        className="absolute top-1/2 -right-32 w-[500px] h-[500px] rounded-full blur-3xl opacity-15 animate-nebula"
        style={{ background: 'radial-gradient(circle, #edc765 0%, rgba(6,11,22,0) 75%)', animationDelay: '-4s' }}
      />
      <div 
        className="absolute bottom-10 left-1/3 w-80 h-80 rounded-full blur-3xl opacity-15 animate-nebula"
        style={{ background: 'radial-gradient(circle, #204d6e 0%, rgba(6,11,22,0) 70%)', animationDelay: '-8s' }}
      />

      {/* Camada de estrelas */}
      {stars.map((star) => (
        <div
          key={star.id}
          className={`absolute rounded-full bg-white ${star.animClass}`}
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            boxShadow: star.size > 2 ? '0 0 6px rgba(255, 255, 255, 0.8)' : 'none',
          }}
        />
      ))}

      {/* Linhas de grade estelar sutil no rodapé */}
      <div className="absolute inset-0 bg-[radial-gradient(#315d78_1px,transparent_1px)] [background-size:48px_48px] opacity-[0.04]" />
    </div>
  );
};
