import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase, type Profile, clearLocalAuthTokens } from '../lib/supabase';
import { GAME_URL } from '../lib/config';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  profileLoading: boolean;
  profileError: string | null;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  launchGame: () => void;
  showGameUrlWarning: boolean;
  setShowGameUrlWarning: (show: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  // Busca o perfil do usuário na tabela profiles com até 3 retentativas
  const fetchProfile = useCallback(async (userId: string, retries = 3): Promise<Profile | null> => {
    setProfileLoading(true);
    setProfileError(null);

    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('id, username, display_name, game_data, created_at, updated_at')
          .eq('id', userId)
          .single();

        if (data && !error) {
          setProfile(data as Profile);
          setProfileLoading(false);
          setProfileError(null);
          return data as Profile;
        }

        if (attempt < retries) {
          // Espera 1 segundo antes de tentar novamente (tempo para o trigger do Supabase concluir)
          await new Promise((res) => setTimeout(res, 1000));
        }
      } catch (err: any) {
        if (attempt === retries) {
          console.warn('Erro ao carregar perfil:', err);
        }
        if (attempt < retries) {
          await new Promise((res) => setTimeout(res, 1000));
        }
      }
    }

    setProfileLoading(false);
    setProfileError('O perfil do piloto ainda está sendo configurado no banco de dados. Clique em recarregar.');
    return null;
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user?.id) {
      await fetchProfile(user.id, 3);
    }
  }, [user, fetchProfile]);

  useEffect(() => {
    let mounted = true;

    // 1. Obter a sessão inicial
    supabase.auth.getSession().then(({ data: { session: initialSession } }) => {
      if (!mounted) return;
      setSession(initialSession);
      setUser(initialSession?.user ?? null);
      if (initialSession?.user) {
        fetchProfile(initialSession.user.id);
      }
      setLoading(false);
    });

    // 2. Escutar mudanças na sessão
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      if (!mounted) return;
      setSession(newSession);
      setUser(newSession?.user ?? null);

      if (newSession?.user) {
        fetchProfile(newSession.user.id);
      } else {
        setProfile(null);
        setProfileError(null);
      }
      setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  const signOut = async () => {
    setLoading(true);
    try {
      await supabase.auth.signOut();
    } finally {
      setSession(null);
      setUser(null);
      setProfile(null);
      setLoading(false);
    }
  };

  const [showGameUrlWarning, setShowGameUrlWarning] = useState(false);

  /**
   * Redireciona o piloto para o jogo com a sessão ativa no fragmento (#)
   */
  const launchGame = () => {
    if (!session?.access_token) {
      window.location.href = '/entrar';
      return;
    }

    if (!GAME_URL || GAME_URL.includes('COLE_AQUI')) {
      setShowGameUrlWarning(true);
      return;
    }

    // Redireciona com os tokens no fragmento (#), NUNCA na query string
    const targetUrl = `${GAME_URL}#access_token=${encodeURIComponent(
      session.access_token
    )}&refresh_token=${encodeURIComponent(session.refresh_token)}`;

    // Remove do localStorage todas as chaves 'sb-*-auth-token' sem chamar signOut()
    clearLocalAuthTokens();

    window.location.href = targetUrl;
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        loading,
        profileLoading,
        profileError,
        signOut,
        refreshProfile,
        launchGame,
        showGameUrlWarning,
        setShowGameUrlWarning,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser utilizado dentro de um AuthProvider');
  }
  return context;
};
