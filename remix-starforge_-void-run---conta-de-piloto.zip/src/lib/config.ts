/**
 * Configuração central da integração Starforge: Void Run
 * Edite as constantes abaixo conforme necessário para apontar para o seu ambiente.
 */

// URL do projeto Supabase existente
export const SUPABASE_URL = "https://kngcdpxofwivbaxsumrb.supabase.co";

// Chave pública (anon/publishable) do Supabase - NUNCA use a service_role
export const SUPABASE_ANON_KEY = "sb_publishable_xRZIbD5-xCO8nSSF2K8W-Q_KN6qnY7P";

// URL de produção do jogo Starforge hospedado no Vercel
export const GAME_URL = "https://supreme-forc.vercel.app/";

/**
 * Validação de formato para o username de piloto do Starforge:
 * ^[a-z0-9][a-z0-9._-]{2,19}$ (3 a 20 caracteres: minúsculas, números, ponto, hífen e underline)
 */
export const USERNAME_REGEX = /^[a-z0-9][a-z0-9._-]{2,19}$/;
