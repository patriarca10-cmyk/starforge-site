import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config';

export interface Profile {
  id: string;
  username: string;
  display_name: string;
  game_data?: Record<string, any> | null;
  created_at: string;
  updated_at?: string;
}

// Inicializa o cliente do Supabase utilizando unicamente a chave pública anon
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

/**
 * Traduz mensagens de erro do Supabase para Português do Brasil amigável
 */
export function translateAuthError(error: any): string {
  if (!error) return 'Ocorreu um erro inesperado. Tente novamente.';
  const message = error.message || (typeof error === 'string' ? error : '');

  if (/user already registered/i.test(message) || /already exists/i.test(message)) {
    return 'Este e-mail já está cadastrado. Você pode entrar diretamente ou recuperar sua senha.';
  }
  if (/invalid login credentials/i.test(message) || /invalid credentials/i.test(message)) {
    return 'E-mail ou senha incorretos. Verifique os dados digitados.';
  }
  if (/email not confirmed/i.test(message)) {
    return 'Seu e-mail ainda não foi confirmado. Por favor, cheque sua caixa de entrada e spam.';
  }
  if (/password should be at least/i.test(message) || /weak password/i.test(message)) {
    return 'A senha é muito fraca. Ela deve conter no mínimo 8 caracteres.';
  }
  if (/rate limit/i.test(message) || /too many requests/i.test(message)) {
    return 'Muitas tentativas em pouco tempo. Aguarde alguns instantes antes de tentar novamente.';
  }
  if (/network/i.test(message) || /fetch failed/i.test(message)) {
    return 'Falha na conexão com a rede estelar. Verifique sua internet e tente novamente.';
  }
  if (/user not found/i.test(message)) {
    return 'Nenhum piloto encontrado com este e-mail.';
  }
  if (/token is expired/i.test(message) || /invalid token/i.test(message) || /recovery link/i.test(message)) {
    return 'O link de recuperação expirou ou é inválido. Solicite um novo link.';
  }

  return message || 'Não foi possível completar a operação no momento.';
}

/**
 * Remove do localStorage todas as chaves que começam com 'sb-' e terminam com '-auth-token'
 * SEM chamar supabase.auth.signOut(), mantendo a sessão perfeitamente válida no servidor para o jogo.
 */
export function clearLocalAuthTokens(): void {
  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('sb-') && key.endsWith('-auth-token')) {
        keysToRemove.push(key);
      }
    }
    for (const key of keysToRemove) {
      localStorage.removeItem(key);
    }
  } catch (err) {
    console.warn('Erro ao remover chaves de autenticação do localStorage:', err);
  }
}
