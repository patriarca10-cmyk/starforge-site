import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Rocket, 
  User, 
  LogOut, 
  Shield, 
  Zap, 
  RefreshCw, 
  Sparkles, 
  Compass, 
  AlertTriangle,
  Radio,
  Clock
} from 'lucide-react';
import heroImg from '../assets/images/starforge_space_hero_1790708443656.jpg';
import { PilotWallet } from '../components/PilotWallet';

export const DashboardPage: React.FC = () => {
  const { session, profile, profileLoading, profileError, refreshProfile, signOut, launchGame } = useAuth();

  const displayName = profile?.display_name || profile?.username || session?.user?.user_metadata?.username || 'Piloto do Vazio';
  const username = profile?.username || session?.user?.user_metadata?.username || 'desconhecido';
  const email = session?.user?.email;

  const registrationDate = profile?.created_at 
    ? new Date(profile.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
    : 'Registro recente';

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:py-12 z-10 relative space-y-8">
      
      {/* ALERTA DE PERFIL PENDENTE / ERRO CASO TRIGGER AINDA NÃO TENHA GERADO LINHA */}
      {profileError && !profile && (
        <div className="starforge-panel p-4 border-amber-500/70 bg-amber-950/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="text-xs text-amber-200">
              <span className="font-semibold">Sincronização em andamento: </span>
              {profileError}
            </div>
          </div>
          <button
            onClick={refreshProfile}
            disabled={profileLoading}
            className="btn-secondary px-3 py-1.5 text-xs flex items-center gap-1.5 rounded cursor-pointer shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${profileLoading ? 'animate-spin' : ''}`} />
            <span>Recarregar</span>
          </button>
        </div>
      )}

      {/* CARTÃO PRINCIPAL DO HANGAR */}
      <div className="starforge-panel p-6 sm:p-8 relative overflow-hidden">
        
        {/* Glow de fundo */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#64baff]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Informações do Piloto */}
          <div className="lg:col-span-7 space-y-4">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#80edbd]/40 bg-[#80edbd]/10 text-xs font-orbitron font-semibold text-[#80edbd]">
              <span className="w-2 h-2 rounded-full bg-[#80edbd] animate-pulse" />
              <span>TERMINAL AUTORIZADO • HANGAR ATIVO</span>
            </div>

            <div className="space-y-1">
              <span className="text-xs uppercase font-orbitron tracking-widest text-[#64baff]">
                Registro de Comando
              </span>
              <h1 className="font-orbitron font-black text-3xl sm:text-4xl text-slate-100 flex items-baseline gap-2">
                Piloto: <span className="text-[#edc765]">{displayName}</span>
              </h1>
              <p className="text-xs text-slate-400 font-mono">
                Identificador: @{username} • {email}
              </p>
            </div>

            {/* Status do Piloto */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
              <div className="bg-[#06101d] border border-[#315d78]/50 p-3 rounded-lg">
                <div className="text-[10px] font-orbitron text-slate-400 uppercase">Status</div>
                <div className="text-xs font-orbitron font-bold text-[#80edbd] mt-0.5">Pronto p/ Voo</div>
              </div>
              <div className="bg-[#06101d] border border-[#315d78]/50 p-3 rounded-lg">
                <div className="text-[10px] font-orbitron text-slate-400 uppercase">Setor</div>
                <div className="text-xs font-orbitron font-bold text-[#64baff] mt-0.5">Vazio Profundo</div>
              </div>
              <div className="bg-[#06101d] border border-[#315d78]/50 p-3 rounded-lg col-span-2 sm:col-span-1">
                <div className="text-[10px] font-orbitron text-slate-400 uppercase">Alistamento</div>
                <div className="text-xs font-orbitron font-bold text-slate-200 mt-0.5 truncate">{registrationDate}</div>
              </div>
            </div>

            {/* BOTÃO JOGAR (GRANDE DOURADO) */}
            <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={launchGame}
                className="btn-gold py-4 px-10 text-base sm:text-lg uppercase tracking-wider rounded-xl flex items-center justify-center gap-3 cursor-pointer shadow-[0_0_30px_rgba(212,169,68,0.45)] hover:shadow-[0_0_45px_rgba(212,169,68,0.7)] transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <Rocket className="w-6 h-6 animate-bounce" />
                <span className="font-extrabold font-orbitron">JOGAR</span>
              </button>

              <button
                onClick={signOut}
                className="btn-secondary py-3.5 px-5 text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 cursor-pointer"
                title="Encerrar sessão no terminal"
              >
                <LogOut className="w-4 h-4 text-[#ff9e9e]" />
                <span>Desconectar</span>
              </button>
            </div>

          </div>

          {/* Imagem da Nave Pronta no Hangar */}
          <div className="lg:col-span-5 relative">
            <div className="rounded-xl overflow-hidden border border-[#edc765]/80 shadow-[0_0_25px_rgba(237,199,101,0.2)] relative group">
              <img
                src={heroImg}
                alt="Caça estelar no hangar"
                className="w-full h-56 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#030711] via-black/30 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3 p-3 rounded-lg bg-[#06101d]/90 backdrop-blur-sm border border-[#315d78]/50 flex items-center justify-between text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-orbitron">Nave Principal</div>
                  <div className="font-orbitron font-bold text-[#fcedb3]">Void Striker #01</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-400 uppercase font-orbitron">Sistemas</div>
                  <div className="font-orbitron font-bold text-[#80edbd]">Online</div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* CARTEIRA DE RECURSOS DO PILOTO (SOMENTE LEITURA) */}
      <PilotWallet
        profile={profile}
        loading={profileLoading}
        error={profileError}
        onRefresh={refreshProfile}
      />

      {/* SEÇÃO INFORMATIVA DE OPERAÇÃO DO JOGO */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="starforge-panel p-5 space-y-2">
          <div className="flex items-center gap-2 text-[#edc765]">
            <Radio className="w-4 h-4" />
            <h2 className="font-orbitron font-semibold text-xs tracking-wider uppercase">
              Autenticação Direta
            </h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Ao clicar em <strong className="text-[#edc765]">JOGAR</strong>, seus tokens de sessão são passados 
            com segurança pelo fragmento da URL. Você entra na cabine imediatamente sem precisar digitar a senha novamente.
          </p>
        </div>

        <div className="starforge-panel p-5 space-y-2">
          <div className="flex items-center gap-2 text-[#64baff]">
            <Compass className="w-4 h-4" />
            <h2 className="font-orbitron font-semibold text-xs tracking-wider uppercase">
              Progresso em Nuvem
            </h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Seus espólios espaciais, naves forjadas e pontuações nas dungeons ficam salvos na sua conta Supabase. 
            Você pode jogar em qualquer computador.
          </p>
        </div>

        <div className="starforge-panel p-5 space-y-2">
          <div className="flex items-center gap-2 text-[#80edbd]">
            <Shield className="w-4 h-4" />
            <h2 className="font-orbitron font-semibold text-xs tracking-wider uppercase">
              Sessão Estelar Ativa
            </h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Sua conexão com os servidores do Starforge permanece protegida por criptografia de ponta a ponta 
            com renovação automática de token.
          </p>
        </div>

      </div>

    </div>
  );
};
