import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, translateAuthError } from '../lib/supabase';
import { Mail, ArrowLeft, Loader2, CheckCircle2, AlertCircle, KeyRound } from 'lucide-react';

export const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email) {
      setErrorMessage('Informe o e-mail de comunicação do seu piloto.');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/redefinir-senha`,
      });

      if (error) {
        setErrorMessage(translateAuthError(error));
        return;
      }

      setSuccess(true);
    } catch (err: any) {
      setErrorMessage(translateAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12 z-10 relative">
      <div className="starforge-panel p-6 sm:p-8">
        
        {/* Cabeçalho */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#64baff]/10 border border-[#64baff]/40 flex items-center justify-center text-[#64baff]">
            <KeyRound className="w-6 h-6" />
          </div>
          <h1 className="font-orbitron font-bold text-2xl text-slate-100">
            Recuperação de Acesso
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Enviaremos um sinal de redefinição de frequência de segurança para seu e-mail.
          </p>
        </div>

        {/* Notificação de Sucesso */}
        {success ? (
          <div className="text-center space-y-4">
            <div className="p-4 rounded-xl bg-[#80edbd]/10 border border-[#80edbd]/40 flex flex-col items-center gap-2 text-xs text-[#80edbd]">
              <CheckCircle2 className="w-8 h-8" />
              <span className="font-bold text-sm">Transmissão de Redefinição Enviada!</span>
              <p className="text-slate-300 leading-relaxed">
                Verifique a caixa de entrada (e spam) de <strong className="text-white">{email}</strong>. 
                Siga o link fornecido para cadastrar uma nova senha de segurança.
              </p>
            </div>

            <div className="pt-3 flex flex-col gap-2">
              <Link
                to="/entrar"
                className="btn-gold w-full py-2.5 text-center text-xs uppercase tracking-wider rounded-lg block font-bold"
              >
                Voltar para o Login
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Mensagem de Erro */}
            {errorMessage && (
              <div 
                className="mb-5 p-3.5 rounded-lg bg-[#ff9e9e]/10 border border-[#ff9e9e]/40 flex items-start gap-3 text-xs text-[#ff9e9e]"
                role="alert"
                aria-live="assertive"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="leading-relaxed">{errorMessage}</div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              <div>
                <label 
                  htmlFor="forgot-email" 
                  className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
                >
                  E-mail Cadastrado *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="forgot-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu.email@exemplo.com"
                    autoComplete="email"
                    required
                    className="starforge-input w-full pl-9 pr-3 py-2.5 text-sm"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-gold w-full py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Transmitindo...</span>
                    </>
                  ) : (
                    <span>Enviar Link de Recuperação</span>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-6 pt-5 border-t border-[#315d78]/40 text-center">
              <Link 
                to="/entrar" 
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#edc765] transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Voltar para tela de entrada</span>
              </Link>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
