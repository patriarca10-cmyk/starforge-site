import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Rocket, Shield, Users, Crosshair, Compass, Zap, ArrowRight } from 'lucide-react';
import heroImg from '../assets/images/starforge_space_hero_1790708443656.jpg';

export const LandingPage: React.FC = () => {
  const { session, launchGame } = useAuth();

  return (
    <div className="relative z-10 flex flex-col gap-16 md:gap-24 pb-20">
      
      {/* HERO SECTION */}
      <section className="relative pt-8 md:pt-14 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Coluna Texto / Ação */}
            <div className="lg:col-span-7 flex flex-col items-start gap-6 text-left">
              
              <div className="inline-flex items-center gap-2.5 px-3 py-1 rounded-full border border-[#edc765]/40 bg-[#edc765]/10 text-xs font-orbitron font-semibold text-[#fcedb3] tracking-wide">
                <span className="w-2 h-2 rounded-full bg-[#80edbd] animate-ping" />
                <span>TERMINAL DE ALISTAMENTO ESTELAR ABERTO</span>
              </div>

              <h1 className="font-orbitron font-black text-4xl sm:text-5xl md:text-6xl text-slate-100 tracking-tight leading-[1.1]">
                STARFORGE <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#edc765] via-[#ffd67a] to-[#64baff]">
                  VOID RUN
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl">
                Space shooter roguelite frenético nas profundezas do cosmos. Pilote naves forjadas em plasma, 
                explore planetas desconhecidos, invada dungeons procedurais do vazio e lidere sua guilda em 
                raids cooperativas colossais.
              </p>

              {/* Botões principais */}
              <div className="flex flex-wrap items-center gap-4 pt-2 w-full sm:w-auto">
                {session ? (
                  <>
                    <button
                      onClick={launchGame}
                      className="btn-gold px-7 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center justify-center gap-2.5 shadow-lg w-full sm:w-auto cursor-pointer"
                    >
                      <Rocket className="w-4 h-4" />
                      <span>JOGAR AGORA</span>
                    </button>
                    <Link
                      to="/painel"
                      className="btn-secondary px-6 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 w-full sm:w-auto text-center"
                    >
                      <span>Ir para o Painel</span>
                      <ArrowRight className="w-4 h-4 text-[#edc765]" />
                    </Link>
                  </>
                ) : (
                  <>
                    <Link
                      to="/cadastro"
                      className="btn-gold px-8 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center justify-center gap-2.5 shadow-lg w-full sm:w-auto"
                    >
                      <Rocket className="w-4 h-4" />
                      <span>Criar Conta de Piloto</span>
                    </Link>
                    <Link
                      to="/entrar"
                      className="btn-secondary px-7 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 w-full sm:w-auto text-center"
                    >
                      <span>Acessar Terminal</span>
                    </Link>
                  </>
                )}
              </div>

              {/* Badges de credibilidade estelar */}
              <div className="pt-4 flex flex-wrap items-center gap-5 text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-[#edc765]" />
                  Servidores Dedicados
                </span>
                <span className="text-[#315d78]">•</span>
                <span className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-[#64baff]" />
                  Ação Roguelite 60 FPS
                </span>
                <span className="text-[#315d78]">•</span>
                <span className="flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-[#80edbd]" />
                  Raids Co-op Multiplayer
                </span>
              </div>
            </div>

            {/* Imagem Hero Estelar */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border border-[#edc765]/80 shadow-[0_0_35px_rgba(237,199,101,0.2)] group">
                <img
                  src={heroImg}
                  alt="Nave de combate estelar Starforge: Void Run"
                  referrerPolicy="no-referrer"
                  className="w-full h-[360px] sm:h-[440px] object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#030711] via-transparent to-transparent opacity-80" />
                
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#06101d]/90 backdrop-blur-md border border-[#315d78]/60 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-orbitron text-[#64baff] uppercase">Caça de Combate</div>
                    <div className="font-orbitron font-bold text-sm text-slate-100">Void Striker MK-IV</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-orbitron text-slate-400">Núcleo Forjado</div>
                    <div className="font-orbitron font-bold text-xs text-[#edc765]">Grau Hiper-Luz</div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* RECURSOS / SOBRE O JOGO */}
      <section id="sobre" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full scroll-mt-24">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-orbitron uppercase text-[#64baff] tracking-widest">
            Sistemas de Combate
          </span>
          <h2 className="font-orbitron font-bold text-2xl sm:text-3xl text-slate-100 mt-2">
            Mecânicas da Borda do Vazio
          </h2>
          <p className="text-sm text-slate-400 mt-3 leading-relaxed">
            Cada expedição espacial testa seus reflexos e tática com progressão permanente e tecnologia antiga.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="starforge-panel p-6 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#edc765]/10 border border-[#edc765]/40 flex items-center justify-center text-[#edc765]">
              <Crosshair className="w-5 h-5" />
            </div>
            <h3 className="font-orbitron font-semibold text-base text-slate-100">
              Naves & Hangares
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Desbloqueie cascos blindados, canhões de íons e motores de salto quântico adaptáveis ao seu estilo de jogo.
            </p>
          </div>

          <div className="starforge-panel p-6 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#64baff]/10 border border-[#64baff]/40 flex items-center justify-center text-[#64baff]">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="font-orbitron font-semibold text-base text-slate-100">
              Planetas & Dungeons
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Explore setores estelares com perigos cósmicos, tempestades de matéria escura e ruínas ancestrais.
            </p>
          </div>

          <div className="starforge-panel p-6 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#80edbd]/10 border border-[#80edbd]/40 flex items-center justify-center text-[#80edbd]">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-orbitron font-semibold text-base text-slate-100">
              Guildas & Alianças
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Junte-se a frotas companheiras, compartilhe recursos em bases orbitais e lidere o ranking de esquadrões.
            </p>
          </div>

          <div className="starforge-panel p-6 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="font-orbitron font-semibold text-base text-slate-100">
              Raids Cooperativas
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Enfrente Leviatãs do Vazio em batalhas épicas para múltiplos jogadores com espólios estelares raros.
            </p>
          </div>

        </div>
      </section>

      {/* BANNER CTA INSCRIÇÃO */}
      <section id="recursos" className="max-w-5xl mx-auto px-4 sm:px-6 w-full scroll-mt-24">
        <div className="starforge-panel p-8 sm:p-12 text-center flex flex-col items-center gap-6 relative overflow-hidden border-[#edc765]">
          <div className="w-14 h-14 rounded-full bg-[#edc765]/20 border border-[#edc765] flex items-center justify-center text-[#edc765] shadow-[0_0_20px_rgba(237,199,101,0.3)]">
            <Rocket className="w-7 h-7" />
          </div>

          <div className="max-w-xl">
            <h2 className="font-orbitron font-bold text-2xl sm:text-3xl text-slate-100">
              Pronto para Comandar sua Nave?
            </h2>
            <p className="text-sm text-slate-300 mt-2 leading-relaxed">
              Crie seu codinome de piloto em poucos segundos. Sua conta é unificada: registre-se aqui e entre 
              imediatamente nos controles da nave.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            {session ? (
              <button
                onClick={launchGame}
                className="btn-gold px-8 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center gap-2 cursor-pointer"
              >
                <Rocket className="w-4 h-4" />
                <span>LANÇAR AO ESPAÇO</span>
              </button>
            ) : (
              <Link
                to="/cadastro"
                className="btn-gold px-8 py-3.5 text-sm uppercase tracking-wider rounded-lg flex items-center gap-2 font-bold"
              >
                <span>CRIAR CONTA AGORA</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            )}
          </div>
        </div>
      </section>

    </div>
  );
};
