import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase, translateAuthError } from '../lib/supabase';
import { Mail, Lock, Eye, EyeOff, Loader2, AlertCircle, LogIn, ArrowRight } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email || !password) {
      setErrorMessage('Por favor, informe seu e-mail e sua senha.');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (error) {
        setErrorMessage(translateAuthError(error));
        return;
      }

      if (data.session) {
        navigate('/painel');
      }
    } catch (err: any) {
      setErrorMessage(translateAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10 sm:py-16 z-10 relative">
      <div className="starforge-panel p-6 sm:p-8">
        
        {/* Cabeçalho */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#edc765]/10 border border-[#edc765]/40 flex items-center justify-center text-[#edc765]">
            <LogIn className="w-6 h-6" />
          </div>
          <h1 className="font-orbitron font-bold text-2xl text-slate-100">
            Acesso ao Terminal
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Entre com suas credenciais de piloto para embarcar na nave.
          </p>
        </div>

        {/* Mensagem de Erro */}
        {errorMessage && (
          <div 
            className="mb-5 p-3.5 rounded-lg bg-[#ff9e9e]/10 border border-[#ff9e9e]/40 flex items-start gap-3 text-xs text-[#ff9e9e]"
            role="alert"
            aria-live="assertive"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="leading-relaxed">{errorMessage}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          
          {/* E-MAIL */}
          <div>
            <label 
              htmlFor="login-email" 
              className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
            >
              E-mail *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu.email@exemplo.com"
                autoComplete="email"
                required
                className="starforge-input w-full pl-9 pr-3 py-2.5 text-sm"
              />
            </div>
          </div>

          {/* SENHA */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label 
                htmlFor="login-password" 
                className="block text-xs font-orbitron font-semibold text-slate-200"
              >
                Senha *
              </label>
              <Link 
                to="/esqueci-senha" 
                className="text-[11px] text-[#64baff] hover:underline"
              >
                Esqueci minha senha
              </Link>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Sua senha de piloto"
                autoComplete="current-password"
                required
                className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                aria-label={showPassword ? 'Ocultar senha' : 'Exibir senha'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* BOTÃO ENTRAR */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="btn-gold w-full py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Autenticando...</span>
                </>
              ) : (
                <>
                  <span>Entrar no Sistema</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {/* Rodapé: Criar conta */}
        <div className="mt-6 pt-5 border-t border-[#315d78]/40 text-center text-xs text-slate-400">
          Ainda não possui codinome de piloto?{' '}
          <Link to="/cadastro" className="text-[#edc765] font-semibold hover:underline">
            Criar conta agora
          </Link>
        </div>

      </div>
    </div>
  );
};
