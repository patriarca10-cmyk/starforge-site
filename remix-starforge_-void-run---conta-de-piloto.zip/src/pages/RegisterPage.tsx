import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase, translateAuthError } from '../lib/supabase';
import { USERNAME_REGEX } from '../lib/config';
import { PasswordStrengthMeter } from '../components/PasswordStrengthMeter';
import { 
  User, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Loader2, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  Rocket,
  ShieldCheck
} from 'lucide-react';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();

  // Campos do formulário
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Controle de exibição de senha
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Estados de verificação de username
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);

  // Estados do envio
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [signupSuccessPendingConfirm, setSignupSuccessPendingConfirm] = useState(false);

  // Referência para debounce timer
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Validação e verificação do username em tempo real
  const handleUsernameChange = (val: string) => {
    // Converte automaticamente para minúsculas
    const lower = val.toLowerCase().trim();
    setUsername(lower);
    setUsernameAvailable(null);
    setUsernameError(null);

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    if (!lower) {
      setCheckingUsername(false);
      return;
    }

    // Valida formato regex local primeiro
    if (!USERNAME_REGEX.test(lower)) {
      if (lower.length < 3) {
        setUsernameError('Mínimo de 3 caracteres necessários');
      } else if (lower.length > 20) {
        setUsernameError('Máximo de 20 caracteres permitidos');
      } else {
        setUsernameError('Apenas letras minúsculas, números, ponto, hífen e underline.');
      }
      setCheckingUsername(false);
      return;
    }

    // Se o formato é válido, consulta a RPC no Supabase com debounce de 500ms
    setCheckingUsername(true);
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const { data, error } = await supabase.rpc('starforge_username_available', {
          requested_username: lower,
        });

        if (error) {
          console.warn('Erro ao checar username via RPC:', error);
          // Fallback caso a RPC falhe
          setUsernameAvailable(null);
        } else {
          setUsernameAvailable(Boolean(data));
          if (!data) {
            setUsernameError('Este nome de piloto já está em uso.');
          }
        }
      } catch (err) {
        console.error('Falha de rede na verificação do nome:', err);
      } finally {
        setCheckingUsername(false);
      }
    }, 500);
  };

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);

    // 1. Validações preliminares
    if (!username || !email || !password || !confirmPassword) {
      setGeneralError('Preencha todos os campos da ficha de alistamento.');
      return;
    }

    if (!USERNAME_REGEX.test(username)) {
      setGeneralError('O nome de usuário não atende aos requisitos de formato.');
      return;
    }

    if (usernameAvailable === false) {
      setGeneralError('Escolha outro nome de usuário, pois este já está ocupado.');
      return;
    }

    if (password.length < 8) {
      setGeneralError('A senha deve possuir no mínimo 8 caracteres.');
      return;
    }

    if (password !== confirmPassword) {
      setGeneralError('As senhas digitadas não coincidem.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 2. Checagem final de disponibilidade do username antes de enviar
      const { data: isAvailable, error: rpcError } = await supabase.rpc('starforge_username_available', {
        requested_username: username,
      });

      if (!rpcError && isAvailable === false) {
        setGeneralError('O nome de usuário acabou de ser reivindicado por outro piloto.');
        setUsernameAvailable(false);
        setIsSubmitting(false);
        return;
      }

      // 3. Cadastro no Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            username: username,
            display_name: username,
          },
          emailRedirectTo: window.location.origin + '/entrar',
        },
      });

      if (error) {
        setGeneralError(translateAuthError(error));
        setIsSubmitting(false);
        return;
      }

      // Se retornou com sessão ativa (confirmação desativada no Supabase), redireciona direto para o painel
      if (data.session) {
        navigate('/painel');
      } else {
        // Se a confirmação de e-mail estiver ativada (session nula), exibe tela de sucesso
        setSignupSuccessPendingConfirm(true);
      }
    } catch (err: any) {
      setGeneralError(translateAuthError(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  // TELA DE SUCESSO CASO CONFIRMAÇÃO DE E-MAIL SEJA EXIGIDA
  if (signupSuccessPendingConfirm) {
    return (
      <div className="max-w-xl mx-auto px-4 py-12">
        <div className="starforge-panel p-8 sm:p-10 text-center flex flex-col items-center gap-5 border-[#80edbd] shadow-[0_0_30px_rgba(128,237,189,0.15)]">
          <div className="w-16 h-16 rounded-full bg-[#80edbd]/15 border border-[#80edbd] flex items-center justify-center text-[#80edbd]">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <h2 className="font-orbitron font-bold text-2xl text-slate-100">
            Conta de Piloto Criada!
          </h2>

          <div className="text-sm text-slate-300 space-y-3 leading-relaxed">
            <p>
              Enviamos um link de confirmação para{' '}
              <strong className="text-[#80edbd] font-mono">{email}</strong>.
            </p>
            <p className="text-xs text-slate-400">
              Acesse sua caixa de entrada (ou pasta de spam), clique no link para ativar seu acesso estelar 
              e retorne para entrar e pilotar sua nave.
            </p>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row gap-3 w-full justify-center">
            <Link
              to="/entrar"
              className="btn-gold px-6 py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 font-bold"
            >
              <span>Ir para a Tela de Entrada</span>
            </Link>
            <Link
              to="/"
              className="btn-secondary px-6 py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2"
            >
              <span>Voltar ao Início</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8 sm:py-12 z-10 relative">
      <div className="starforge-panel p-6 sm:p-8">
        
        {/* Cabeçalho do formulário */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 text-xs font-orbitron uppercase text-[#edc765] tracking-widest mb-1.5">
            <ShieldCheck className="w-4 h-4" />
            <span>Registro da Federação Estelar</span>
          </div>
          <h1 className="font-orbitron font-bold text-2xl sm:text-3xl text-slate-100">
            Criar Conta de Piloto
          </h1>
          <p className="text-xs text-slate-400 mt-1.5">
            Garante acesso imediato ao Starforge: Void Run com perfil unificado.
          </p>
        </div>

        {/* Mensagem de Erro Geral */}
        {generalError && (
          <div 
            className="mb-5 p-3.5 rounded-lg bg-[#ff9e9e]/10 border border-[#ff9e9e]/40 flex items-start gap-3 text-xs text-[#ff9e9e]"
            role="alert"
            aria-live="assertive"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="leading-relaxed">{generalError}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          
          {/* CAMPO USUÁRIO */}
          <div>
            <label 
              htmlFor="username" 
              className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
            >
              Nome de Usuário (Piloto) *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                placeholder="ex: valkyrie_01"
                autoComplete="username"
                maxLength={20}
                required
                className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                {checkingUsername ? (
                  <Loader2 className="w-4 h-4 text-[#64baff] animate-spin" />
                ) : usernameAvailable === true ? (
                  <span title="Disponível">
                    <CheckCircle2 className="w-4 h-4 text-[#80edbd]" />
                  </span>
                ) : usernameAvailable === false ? (
                  <span title="Em uso">
                    <AlertCircle className="w-4 h-4 text-[#ff9e9e]" />
                  </span>
                ) : null}
              </div>
            </div>

            {/* Regras e status do username */}
            <div className="mt-1.5 flex flex-col gap-1 text-[11px]">
              {usernameError ? (
                <span className="text-[#ff9e9e] flex items-center gap-1 font-medium">
                  {usernameError}
                </span>
              ) : usernameAvailable === true ? (
                <span className="text-[#80edbd] flex items-center gap-1 font-medium">
                  ✓ Nome de piloto disponível para alistamento!
                </span>
              ) : null}
              <span className="text-slate-500">
                3 a 20 caracteres: letras minúsculas, números, ponto (.), hífen (-) e underline (_).
              </span>
            </div>
          </div>

          {/* CAMPO E-MAIL */}
          <div>
            <label 
              htmlFor="email" 
              className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
            >
              E-mail de Comunicação *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu.email@exemplo.com"
                autoComplete="email"
                required
                className="starforge-input w-full pl-9 pr-3 py-2.5 text-sm"
              />
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Utilizado para login e recuperação de acesso às suas naves.
            </p>
          </div>

          {/* CAMPO SENHA */}
          <div>
            <label 
              htmlFor="password" 
              className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
            >
              Senha de Segurança *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo 8 caracteres"
                autoComplete="new-password"
                required
                className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                aria-label={showPassword ? 'Ocultar senha' : 'Exibir senha'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Medidor visual de força da senha */}
            <PasswordStrengthMeter password={password} />
          </div>

          {/* CAMPO CONFIRMAÇÃO DE SENHA */}
          <div>
            <label 
              htmlFor="confirmPassword" 
              className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
            >
              Confirmar Senha *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="confirmPassword"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repita a senha digitada"
                autoComplete="new-password"
                required
                className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                aria-label={showConfirmPassword ? 'Ocultar confirmação de senha' : 'Exibir confirmação de senha'}
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {confirmPassword && password !== confirmPassword && (
              <p className="text-[11px] text-[#ff9e9e] mt-1">
                As senhas não coincidem.
              </p>
            )}
          </div>

          {/* BOTÃO ENVIAR */}
          <div className="pt-3">
            <button
              type="submit"
              disabled={isSubmitting || checkingUsername}
              className="btn-gold w-full py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Cadastrando Piloto...</span>
                </>
              ) : (
                <>
                  <Rocket className="w-4 h-4" />
                  <span>Finalizar Registro & Jogar</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Rodapé do card com link para Login */}
        <div className="mt-6 pt-5 border-t border-[#315d78]/40 text-center text-xs text-slate-400">
          Já possui registro na frota?{' '}
          <Link to="/entrar" className="text-[#edc765] font-semibold hover:underline">
            Acessar com minha conta
          </Link>
        </div>

      </div>
    </div>
  );
};
