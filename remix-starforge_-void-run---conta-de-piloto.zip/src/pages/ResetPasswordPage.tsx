import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase, translateAuthError } from '../lib/supabase';
import { PasswordStrengthMeter } from '../components/PasswordStrengthMeter';
import { Lock, Eye, EyeOff, Loader2, CheckCircle2, AlertCircle, ShieldAlert, Rocket } from 'lucide-react';

export const ResetPasswordPage: React.FC = () => {
  const navigate = useNavigate();

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [isRecoveryMode, setIsRecoveryMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    // Escuta evento de PASSWORD_RECOVERY emitido pelo Supabase
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY' || (event === 'SIGNED_IN' && window.location.hash.includes('type=recovery'))) {
        setIsRecoveryMode(true);
      }
    });

    // Também verifica se já há um token de recovery no hash ou sessão ativa
    if (window.location.hash.includes('type=recovery') || window.location.hash.includes('access_token')) {
      setIsRecoveryMode(true);
    } else {
      // Verifica se o usuário tem sessão ativa
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session) {
          setIsRecoveryMode(true);
        }
      });
    }

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!password || !confirmPassword) {
      setErrorMessage('Informe a nova senha e a confirmação.');
      return;
    }

    if (password.length < 8) {
      setErrorMessage('A nova senha deve possuir no mínimo 8 caracteres.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('As senhas digitadas não coincidem.');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.updateUser({
        password: password,
      });

      if (error) {
        setErrorMessage(translateAuthError(error));
        return;
      }

      setSuccess(true);
    } catch (err: any) {
      setErrorMessage(translateAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12 z-10 relative">
      <div className="starforge-panel p-6 sm:p-8">
        
        {/* Cabeçalho */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#edc765]/10 border border-[#edc765]/40 flex items-center justify-center text-[#edc765]">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="font-orbitron font-bold text-2xl text-slate-100">
            Nova Senha de Piloto
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Redefina a chave de autenticação para retornar à cabine da sua nave.
          </p>
        </div>

        {/* Notificação de Sucesso */}
        {success ? (
          <div className="text-center space-y-4">
            <div className="p-4 rounded-xl bg-[#80edbd]/10 border border-[#80edbd]/40 flex flex-col items-center gap-2 text-xs text-[#80edbd]">
              <CheckCircle2 className="w-8 h-8" />
              <span className="font-bold text-sm">Senha Atualizada com Sucesso!</span>
              <p className="text-slate-300 leading-relaxed">
                Suas novas credenciais estelares foram registradas no terminal. Você já pode acessar o jogo.
              </p>
            </div>

            <div className="pt-3">
              <button
                onClick={() => navigate('/painel')}
                className="btn-gold w-full py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 font-bold cursor-pointer"
              >
                <Rocket className="w-4 h-4" />
                <span>Ir para o Hangar & Jogar</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Mensagem de Erro */}
            {errorMessage && (
              <div 
                className="mb-5 p-3.5 rounded-lg bg-[#ff9e9e]/10 border border-[#ff9e9e]/40 flex items-start gap-3 text-xs text-[#ff9e9e]"
                role="alert"
                aria-live="assertive"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="leading-relaxed">{errorMessage}</div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              
              {/* NOVA SENHA */}
              <div>
                <label 
                  htmlFor="new-password" 
                  className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
                >
                  Nova Senha *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="new-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Mínimo 8 caracteres"
                    autoComplete="new-password"
                    required
                    className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                    aria-label={showPassword ? 'Ocultar senha' : 'Exibir senha'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <PasswordStrengthMeter password={password} />
              </div>

              {/* CONFIRMAR NOVA SENHA */}
              <div>
                <label 
                  htmlFor="confirm-new-password" 
                  className="block text-xs font-orbitron font-semibold text-slate-200 mb-1.5"
                >
                  Confirmar Nova Senha *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="confirm-new-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repita a nova senha"
                    autoComplete="new-password"
                    required
                    className="starforge-input w-full pl-9 pr-10 py-2.5 text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                    aria-label={showConfirmPassword ? 'Ocultar senha' : 'Exibir senha'}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-gold w-full py-3 text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Atualizando Senha...</span>
                    </>
                  ) : (
                    <span>Salvar Nova Senha</span>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-6 pt-5 border-t border-[#315d78]/40 text-center">
              <Link 
                to="/entrar" 
                className="text-xs text-slate-400 hover:text-[#edc765] transition-colors"
              >
                Cancelar e voltar ao login
              </Link>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
